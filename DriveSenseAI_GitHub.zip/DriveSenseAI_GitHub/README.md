# DriveSense AI

DriveSense AI is an intelligent automotive diagnostic and predictive maintenance platform developed using Flask, Python and OBD-II technologies. The system combines live telemetry monitoring, AI-assisted diagnostics, predictive maintenance analysis and responsive web technologies within a unified automotive software platform.

---

# Features

- User authentication and secure login
- Live vehicle telemetry monitoring
- OBD-II diagnostic trouble code scanning
- AI-assisted fault explanations
- Predictive maintenance analysis
- Vehicle health scoring
- Service history management
- PDF diagnostic report generation
- AI image-based vehicle analysis
- Responsive dashboard interface
- Mobile and desktop compatibility

---

# Technologies Used

- Python
- Flask
- HTML5
- CSS3
- JavaScript
- SQLite
- OBD-II communication libraries
- OpenAI / Ollama AI integration
- Whisper speech recognition
- LLAVA image analysis
- ReportLab PDF generation

---

# Installation

## 1. Clone or Extract the Project

Extract the project ZIP file or clone the repository.

---

## 2. Open the Project

Open the DriveSenseAI project folder inside Visual Studio Code.

---

## 3. Create Virtual Environment

```bash
python -m venv venv
```

---

## 4. Activate Virtual Environment

### Windows

```bash
venv\Scripts\activate
```

### macOS / Linux

```bash
source venv/bin/activate
```

---

## 5. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## 6. Install Ollama (Optional AI Features)

Download and install Ollama:

https://ollama.com

After installation, pull the required AI models:

```bash
ollama pull llava
ollama pull mistral
```

---

## 7. Run the Application

```bash
python run.py
```

The Flask server will start locally:

```bash
http://127.0.0.1:5000
```

---

# How to Use the Application

## 1. Register and Login

- Open the application in a browser
- Create a user account
- Login to access the DriveSense AI dashboard

---

## 2. Connect Vehicle

- Navigate to the Connect page
- Connect the ENET or OBD-II interface to the vehicle
- Establish communication between the laptop and vehicle

---

## 3. View Live Dashboard

The dashboard displays:
- Vehicle telemetry
- Speed
- RPM
- Tyre pressure
- Vehicle health data
- Predictive maintenance information

---

## 4. Run Diagnostic Scan

- Open the Diagnostics page
- Start a vehicle scan
- The system will retrieve diagnostic trouble codes (DTCs)

---

## 5. Use AI Fault Explanation

- Select a detected fault code
- Open the AI explanation section
- The AI assistant provides:
  - Fault descriptions
  - Maintenance recommendations
  - Suggested repair guidance

---

## 6. Predictive Maintenance

The predictive maintenance section analyses:
- Vehicle condition
- Service intervals
- Telemetry behaviour
- Potential future maintenance requirements

---

## 7. Vehicle Image Diagnostics

- Upload a vehicle or engine image
- The LLAVA AI model analyses visible vehicle conditions
- The system generates AI-assisted visual inspection feedback

---

## 8. Service History Management

The Service Records section allows:
- Viewing maintenance history
- Monitoring previous services
- Tracking vehicle maintenance status

---

## 9. Export Diagnostic Reports

The platform supports PDF report generation for:
- Diagnostic scans
- Vehicle health reports
- AI analysis summaries

---

# Project Structure

```text
DriveSenseAI/
│
├── app/
│   ├── api/
│   ├── data/
│   ├── ml/
│   ├── services/
│   ├── static/
│   ├── templates/
│   ├── routes.py
│   └── __init__.py
│
├── venv/
├── requirements.txt
├── README.md
└── run.py
```

---

# Testing Environment

The system was tested using:
- BMW F20 vehicle platform
- ENET Ethernet-to-OBD diagnostic interface
- Live telemetry communication
- Practical real-world vehicle validation

---

# Future Improvements

Potential future developments include:
- Mobile application deployment
- Advanced machine learning models
- Cloud-based vehicle analytics
- Expanded predictive maintenance capabilities
- Enhanced AI voice assistant functionality
- Additional vehicle manufacturer support

---

# Academic Project Information

This project was developed as part of a university software engineering dissertation focused on intelligent automotive diagnostics, AI-assisted maintenance systems and real-time telemetry processing.

---

# Author

Dasheill Knicx Vas  
DriveSense AI Dissertation Project  
Developed using Python, Flask and AI-assisted automotive technologies.

---

# Project Purpose

DriveSense AI was developed as part of an academic dissertation project focused on intelligent automotive diagnostics, real-time telemetry monitoring and AI-assisted predictive maintenance systems. The project demonstrates the integration of software engineering, artificial intelligence and vehicle communication technologies within a practical automotive environment.